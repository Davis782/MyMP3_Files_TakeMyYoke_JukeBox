import React from 'react';
import AdminPanel from '../components/Admin/AdminPanel';
import LoginForm from '../components/Admin/LoginForm';
import useAuthStore from '../store/authStore';

const Admin: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuthStore();
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  return isAuthenticated ? <AdminPanel /> : <LoginForm />;
};

export default Admin;