import React, { useEffect } from 'react';
import ImageGallery from '../components/Media/ImageGallery';
import useMediaStore from '../store/mediaStore';

const Gallery: React.FC = () => {
  const { fetchMedia } = useMediaStore();
  
  useEffect(() => {
    fetchMedia();
  }, [fetchMedia]);

  return <ImageGallery />;
};

export default Gallery;