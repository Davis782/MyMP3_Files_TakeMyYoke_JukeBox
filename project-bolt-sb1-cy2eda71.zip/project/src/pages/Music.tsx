import React, { useEffect } from 'react';
import AudioPlayer from '../components/Media/AudioPlayer';
import useMediaStore from '../store/mediaStore';

const Music: React.FC = () => {
  const { fetchMedia } = useMediaStore();
  
  useEffect(() => {
    fetchMedia();
  }, [fetchMedia]);

  return <AudioPlayer />;
};

export default Music;