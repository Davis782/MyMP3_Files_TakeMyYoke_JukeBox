export interface MediaFile {
  id: string;
  name: string;
  path: string;
  type: 'audio' | 'image';
  description?: string;
  lyrics?: string;
  folderId?: string;
  cashAppHandle?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  username: string;
  isAdmin: boolean;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

export interface MediaState {
  audioFiles: MediaFile[];
  imageFiles: MediaFile[];
  currentMedia: MediaFile | null;
  isPlaying: boolean;
  isLoading: boolean;
  error: string | null;
  cashAppHandle: string;
}