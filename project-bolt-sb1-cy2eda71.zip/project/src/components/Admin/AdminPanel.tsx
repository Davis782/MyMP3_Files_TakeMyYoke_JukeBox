import React from 'react';
import MediaUploadForm from './MediaUploadForm';
import MediaManagement from './MediaManagement';
import CashAppSettings from './CashAppSettings';
import { Settings } from 'lucide-react';

const AdminPanel: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center mb-4">
        <Settings className="mr-2" size={24} />
        <h1 className="text-2xl font-bold">Admin Panel</h1>
      </div>
      
      <MediaUploadForm />
      <CashAppSettings />
      <MediaManagement />
    </div>
  );
};

export default AdminPanel;