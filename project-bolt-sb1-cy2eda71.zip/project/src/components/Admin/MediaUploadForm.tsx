import React, { useState, useRef } from 'react';
import { Upload, Music, Image as ImageIcon, DollarSign } from 'lucide-react';
import useMediaStore from '../../store/mediaStore';

const MediaUploadForm: React.FC = () => {
  const [mediaType, setMediaType] = useState<'audio' | 'image'>('audio');
  const [file, setFile] = useState<File | null>(null);
  const [lyrics, setLyrics] = useState('');
  const [description, setDescription] = useState('');
  const [folderName, setFolderName] = useState('');
  const [cashAppHandle, setCashAppHandle] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { uploadMedia, isLoading, error, cashAppHandle: defaultCashAppHandle } = useMediaStore();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      
      // Auto-generate folder name from file name (remove extension)
      if (mediaType === 'audio' && !folderName) {
        setFolderName(selectedFile.name.replace(/\.[^/.]+$/, ""));
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;
    
    try {
      await uploadMedia(
        file, 
        mediaType, 
        mediaType === 'audio' 
          ? { 
              lyrics, 
              folderName,
              cashAppHandle: cashAppHandle || defaultCashAppHandle
            } 
          : { description }
      );
      
      // Reset form
      setFile(null);
      setLyrics('');
      setDescription('');
      setFolderName('');
      setCashAppHandle('');
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (err) {
      console.error('Upload failed:', err);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-xl font-bold mb-4 flex items-center">
        <Upload className="mr-2" size={20} />
        Upload Media
      </h2>
      
      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Media Type
          </label>
          <div className="flex space-x-4">
            <button
              type="button"
              onClick={() => setMediaType('audio')}
              className={`flex items-center px-4 py-2 rounded-md ${
                mediaType === 'audio' 
                  ? 'bg-blue-100 text-blue-700 border border-blue-300' 
                  : 'bg-gray-100 text-gray-700 border border-gray-300'
              }`}
            >
              <Music size={18} className="mr-2" />
              Audio
            </button>
            <button
              type="button"
              onClick={() => setMediaType('image')}
              className={`flex items-center px-4 py-2 rounded-md ${
                mediaType === 'image' 
                  ? 'bg-blue-100 text-blue-700 border border-blue-300' 
                  : 'bg-gray-100 text-gray-700 border border-gray-300'
              }`}
            >
              <ImageIcon size={18} className="mr-2" />
              Image
            </button>
          </div>
        </div>
        
        <div className="mb-4">
          <label htmlFor="file" className="block text-sm font-medium text-gray-700 mb-1">
            Select File
          </label>
          <input
            ref={fileInputRef}
            id="file"
            type="file"
            accept={mediaType === 'audio' ? 'audio/*' : 'image/*'}
            onChange={handleFileChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        
        {mediaType === 'audio' && (
          <>
            <div className="mb-4">
              <label htmlFor="folderName" className="block text-sm font-medium text-gray-700 mb-1">
                Folder Name
              </label>
              <input
                id="folderName"
                type="text"
                value={folderName}
                onChange={(e) => setFolderName(e.target.value)}
                placeholder="Folder name for this audio file"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
              <p className="mt-1 text-xs text-gray-500">
                This will create a subfolder to store the MP3 and its lyrics file
              </p>
            </div>
            
            <div className="mb-4">
              <label htmlFor="lyrics" className="block text-sm font-medium text-gray-700 mb-1">
                Lyrics
              </label>
              <textarea
                id="lyrics"
                value={lyrics}
                onChange={(e) => setLyrics(e.target.value)}
                rows={5}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
              <p className="mt-1 text-xs text-gray-500">
                These lyrics will be saved in a text file alongside the MP3
              </p>
            </div>
            
            <div className="mb-4">
              <label htmlFor="cashAppHandle" className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                <DollarSign size={16} className="mr-1" />
                CashApp Handle (Optional)
              </label>
              <input
                id="cashAppHandle"
                type="text"
                value={cashAppHandle}
                onChange={(e) => setCashAppHandle(e.target.value)}
                placeholder={defaultCashAppHandle}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="mt-1 text-xs text-gray-500">
                Custom CashApp handle for this specific track (leave empty to use default)
              </p>
            </div>
          </>
        )}
        
        {mediaType === 'image' && (
          <div className="mb-4">
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
              Description (optional)
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        )}
        
        <button
          type="submit"
          disabled={!file || isLoading}
          className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Uploading...' : 'Upload Media'}
        </button>
      </form>
    </div>
  );
};

export default MediaUploadForm;