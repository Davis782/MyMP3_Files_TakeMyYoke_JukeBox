import React, { useState } from 'react';
import { Trash2, Edit, Save, X, Music, Image as ImageIcon, DollarSign } from 'lucide-react';
import useMediaStore from '../../store/mediaStore';

const MediaManagement: React.FC = () => {
  const { audioFiles, imageFiles, deleteMedia, updateMediaMetadata, isLoading } = useMediaStore();
  const [activeTab, setActiveTab] = useState<'audio' | 'image'>('audio');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editLyrics, setEditLyrics] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editCashAppHandle, setEditCashAppHandle] = useState('');

  const handleEdit = (id: string, type: 'audio' | 'image') => {
    const file = type === 'audio' 
      ? audioFiles.find(f => f.id === id)
      : imageFiles.find(f => f.id === id);
      
    if (file) {
      setEditingId(id);
      setEditName(file.name);
      if (type === 'audio') {
        setEditLyrics(file.lyrics || '');
        setEditCashAppHandle(file.cashAppHandle || '');
      } else if (type === 'image') {
        setEditDescription(file.description || '');
      }
    }
  };

  const handleSave = async (id: string, type: 'audio' | 'image') => {
    try {
      await updateMediaMetadata(
        id, 
        type, 
        type === 'audio' 
          ? { name: editName, lyrics: editLyrics, cashAppHandle: editCashAppHandle } 
          : { name: editName, description: editDescription }
      );
      setEditingId(null);
    } catch (err) {
      console.error('Update failed:', err);
    }
  };

  const handleDelete = async (id: string, type: 'audio' | 'image') => {
    if (window.confirm('Are you sure you want to delete this media?')) {
      try {
        await deleteMedia(id, type);
      } catch (err) {
        console.error('Delete failed:', err);
      }
    }
  };

  const renderAudioFiles = () => {
    if (audioFiles.length === 0) {
      return (
        <div className="text-center py-6 text-gray-500">
          <p>No audio files available</p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {audioFiles.map((audio) => (
          <div key={audio.id} className="border border-gray-200 rounded-lg p-4">
            {editingId === audio.id ? (
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    File Name
                  </label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Lyrics
                  </label>
                  <textarea
                    value={editLyrics}
                    onChange={(e) => setEditLyrics(e.target.value)}
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                    <DollarSign size={16} className="mr-1" />
                    CashApp Handle
                  </label>
                  <input
                    type="text"
                    value={editCashAppHandle}
                    onChange={(e) => setEditCashAppHandle(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    placeholder="$YourCashAppHandle"
                  />
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleSave(audio.id, 'audio')}
                    disabled={isLoading}
                    className="flex items-center px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700"
                  >
                    <Save size={16} className="mr-1" />
                    Save
                  </button>
                  <button
                    onClick={() => setEditingId(null)}
                    className="flex items-center px-3 py-1 bg-gray-600 text-white rounded-md hover:bg-gray-700"
                  >
                    <X size={16} className="mr-1" />
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                      <Music size={18} className="text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">{audio.name}</h3>
                      <div className="flex items-center text-sm text-gray-500">
                        <span className="mr-2">
                          {new Date(audio.updatedAt).toLocaleDateString()}
                        </span>
                        {audio.folderId && (
                          <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded text-xs">
                            Folder: {audio.folderId}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleEdit(audio.id, 'audio')}
                      className="p-1 text-gray-600 hover:text-blue-600"
                    >
                      <Edit size={18} />
                    </button>
                    <button
                      onClick={() => handleDelete(audio.id, 'audio')}
                      className="p-1 text-gray-600 hover:text-red-600"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
                {audio.lyrics && (
                  <div className="mt-2 pl-13">
                    <p className="text-sm text-gray-700 whitespace-pre-line line-clamp-2">
                      {audio.lyrics}
                    </p>
                  </div>
                )}
                {audio.cashAppHandle && (
                  <div className="mt-2 pl-13 flex items-center text-sm text-gray-600">
                    <DollarSign size={14} className="mr-1" />
                    <span>{audio.cashAppHandle}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  const renderImageFiles = () => {
    if (imageFiles.length === 0) {
      return (
        <div className="text-center py-6 text-gray-500">
          <p>No image files available</p>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {imageFiles.map((image) => (
          <div key={image.id} className="border border-gray-200 rounded-lg overflow-hidden">
            {editingId === image.id ? (
              <div className="p-4 space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    File Name
                  </label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={editDescription}
                    onChange={(e) => setEditDescription(e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  />
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleSave(image.id, 'image')}
                    disabled={isLoading}
                    className="flex items-center px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700"
                  >
                    <Save size={16} className="mr-1" />
                    Save
                  </button>
                  <button
                    onClick={() => setEditingId(null)}
                    className="flex items-center px-3 py-1 bg-gray-600 text-white rounded-md hover:bg-gray-700"
                  >
                    <X size={16} className="mr-1" />
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="relative h-40">
                  <img 
                    src={image.path} 
                    alt={image.name} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2 flex space-x-1">
                    <button
                      onClick={() => handleEdit(image.id, 'image')}
                      className="p-1 bg-white bg-opacity-80 rounded-full text-gray-700 hover:text-blue-600"
                    >
                      <Edit size={16} />
                    </button>
                    <button
                      onClick={() => handleDelete(image.id, 'image')}
                      className="p-1 bg-white bg-opacity-80 rounded-full text-gray-700 hover:text-red-600"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-medium">{image.name}</h3>
                  {image.description && (
                    <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                      {image.description}
                    </p>
                  )}
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold mb-4">Media Management</h2>
      
      <div className="mb-6 border-b border-gray-200">
        <div className="flex space-x-4">
          <button
            onClick={() => setActiveTab('audio')}
            className={`py-2 px-4 border-b-2 font-medium ${
              activeTab === 'audio'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <div className="flex items-center">
              <Music size={18} className="mr-2" />
              Audio Files
            </div>
          </button>
          <button
            onClick={() => setActiveTab('image')}
            className={`py-2 px-4 border-b-2 font-medium ${
              activeTab === 'image'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <div className="flex items-center">
              <ImageIcon size={18} className="mr-2" />
              Image Files
            </div>
          </button>
        </div>
      </div>
      
      {activeTab === 'audio' ? renderAudioFiles() : renderImageFiles()}
    </div>
  );
};

export default MediaManagement;