import React from 'react';
import { DollarSign } from 'lucide-react';
import useMediaStore from '../../store/mediaStore';

const DonationSection: React.FC = () => {
  const { cashAppHandle } = useMediaStore();

  const handleCashAppDonation = () => {
    // In a real app, this would open CashApp or redirect to a payment page
    window.open(`https://cash.app/${cashAppHandle.replace('$', '')}`, '_blank');
  };

  return (
    <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-lg shadow-md p-6 text-white">
      <h2 className="text-xl font-bold mb-3 flex items-center">
        <DollarSign className="mr-2" size={20} />
        Support This Project
      </h2>
      
      <p className="mb-4">
        If you enjoy using this media player, consider supporting the development through CashApp.
        Your donations help maintain and improve the application.
      </p>
      
      <div className="bg-white bg-opacity-20 p-4 rounded-lg mb-4">
        <p className="font-medium">{cashAppHandle}</p>
      </div>
      
      <button
        onClick={handleCashAppDonation}
        className="w-full bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-md transition-colors flex items-center justify-center"
      >
        <DollarSign size={18} className="mr-2" />
        Send Support
      </button>
      
      <div className="mt-4 space-y-2">
        <h3 className="font-medium">Premium Features Coming Soon:</h3>
        <ul className="list-disc list-inside space-y-1 ml-2">
          <li>Ad-free experience</li>
          <li>Offline playback</li>
          <li>Custom playlists</li>
          <li>High-quality audio streaming</li>
        </ul>
      </div>
    </div>
  );
};

export default DonationSection;