import React, { useEffect } from 'react';
import { Music, Image, Info } from 'lucide-react';
import { Link } from 'react-router-dom';
import RecentMedia from './RecentMedia';
import DonationSection from './DonationSection';
import useMediaStore from '../../store/mediaStore';

const HomePage: React.FC = () => {
  const { fetchMedia, audioFiles, imageFiles } = useMediaStore();
  
  useEffect(() => {
    fetchMedia();
  }, [fetchMedia]);

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white rounded-lg shadow-md p-8">
        <h1 className="text-3xl font-bold mb-2">Welcome to Media Player</h1>
        <p className="text-blue-100 mb-6">
          Your personal media library for music and images
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link 
            to="/music" 
            className="bg-white bg-opacity-20 hover:bg-opacity-30 p-6 rounded-lg flex items-center transition-colors"
          >
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mr-4">
              <Music size={24} className="text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold">Music Library</h2>
              <p className="text-blue-100">{audioFiles.length} audio files available</p>
            </div>
          </Link>
          
          <Link 
            to="/gallery" 
            className="bg-white bg-opacity-20 hover:bg-opacity-30 p-6 rounded-lg flex items-center transition-colors"
          >
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mr-4">
              <Image size={24} className="text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold">Image Gallery</h2>
              <p className="text-blue-100">{imageFiles.length} images available</p>
            </div>
          </Link>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <RecentMedia />
        </div>
        <div>
          <DonationSection />
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-bold mb-4 flex items-center">
          <Info className="mr-2" size={20} />
          About This Application
        </h2>
        <p className="text-gray-700 mb-4">
          This media player application allows you to manage and enjoy your personal collection of music and images.
          Upload your files, organize them, and access them from anywhere.
        </p>
        <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
          <h3 className="font-medium text-blue-700 mb-2">Features:</h3>
          <ul className="list-disc list-inside space-y-1 text-gray-700">
            <li>Music playback with lyrics display</li>
            <li>Image gallery with fullscreen view</li>
            <li>File management system</li>
            <li>Admin panel for content management</li>
            <li>Responsive design for all devices</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default HomePage;