import React from 'react';
import { Clock, Music, Image as ImageIcon } from 'lucide-react';
import useMediaStore from '../../store/mediaStore';

const RecentMedia: React.FC = () => {
  const { audioFiles, imageFiles, setCurrentMedia } = useMediaStore();
  
  // Get the 3 most recent files from each type
  const recentAudio = [...audioFiles]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 3);
    
  const recentImages = [...imageFiles]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 3);

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold mb-4 flex items-center">
        <Clock className="mr-2" size={20} />
        Recently Added
      </h2>
      
      {recentAudio.length === 0 && recentImages.length === 0 ? (
        <div className="text-center py-6 text-gray-500">
          <p>No recent media available</p>
        </div>
      ) : (
        <div className="space-y-6">
          {recentAudio.length > 0 && (
            <div>
              <h3 className="text-lg font-medium mb-3 flex items-center">
                <Music className="mr-2" size={18} />
                Audio
              </h3>
              <div className="space-y-2">
                {recentAudio.map((audio) => (
                  <div 
                    key={audio.id}
                    className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
                    onClick={() => setCurrentMedia(audio)}
                  >
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                      <Music size={14} className="text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">{audio.name}</h4>
                      <p className="text-xs text-gray-500">
                        {new Date(audio.updatedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {recentImages.length > 0 && (
            <div>
              <h3 className="text-lg font-medium mb-3 flex items-center">
                <ImageIcon className="mr-2" size={18} />
                Images
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {recentImages.map((image) => (
                  <div 
                    key={image.id}
                    className="relative rounded-lg overflow-hidden cursor-pointer h-24 group"
                    onClick={() => setCurrentMedia(image)}
                  >
                    <img 
                      src={image.path} 
                      alt={image.name} 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-opacity flex items-end">
                      <div className="p-2 w-full bg-gradient-to-t from-black to-transparent">
                        <h4 className="text-white text-sm truncate">{image.name}</h4>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default RecentMedia;