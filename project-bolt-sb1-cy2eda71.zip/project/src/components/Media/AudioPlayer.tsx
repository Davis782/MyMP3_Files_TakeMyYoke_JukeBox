import React, { useState } from 'react';
import useMediaStore from '../../store/mediaStore';
import { Music, DollarSign } from 'lucide-react';

const AudioPlayer: React.FC = () => {
  const { audioFiles, setCurrentMedia, currentMedia } = useMediaStore();
  const [showLyrics, setShowLyrics] = useState(false);

  const handlePlayAudio = (audio: any) => {
    setCurrentMedia(audio);
  };

  const handleCashAppDonation = (cashAppHandle: string) => {
    // In a real app, this would open CashApp or redirect to a payment page
    window.open(`https://cash.app/${cashAppHandle.replace('$', '')}`, '_blank');
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6 flex items-center">
        <Music className="mr-2" />
        Music Library
      </h2>
      
      {audioFiles.length === 0 ? (
        <div className="text-center py-10 text-gray-500">
          <p>No audio files available</p>
        </div>
      ) : (
        <div className="space-y-4">
          {audioFiles.map((audio) => (
            <div 
              key={audio.id}
              className={`p-4 rounded-lg cursor-pointer transition-colors ${
                currentMedia?.id === audio.id ? 'bg-blue-50 border border-blue-200' : 'hover:bg-gray-50 border border-gray-200'
              }`}
              onClick={() => handlePlayAudio(audio)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                    <Music size={18} className="text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">{audio.name}</h3>
                    <div className="flex items-center text-sm text-gray-500">
                      <span className="mr-2">
                        {new Date(audio.updatedAt).toLocaleDateString()}
                      </span>
                      {audio.folderId && (
                        <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded text-xs">
                          Folder: {audio.folderId}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  {currentMedia?.id === audio.id && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowLyrics(!showLyrics);
                      }}
                      className="text-sm text-blue-600 hover:text-blue-800 px-3 py-1 border border-blue-200 rounded-md"
                    >
                      {showLyrics ? 'Hide Lyrics' : 'Show Lyrics'}
                    </button>
                  )}
                  
                  {audio.cashAppHandle && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCashAppDonation(audio.cashAppHandle || '$YourCashAppHandle');
                      }}
                      className="flex items-center text-sm text-green-600 hover:text-green-800 px-3 py-1 border border-green-200 rounded-md bg-green-50"
                    >
                      <DollarSign size={16} className="mr-1" />
                      Support
                    </button>
                  )}
                </div>
              </div>
              
              {currentMedia?.id === audio.id && showLyrics && audio.lyrics && (
                <div className="mt-4 p-4 bg-gray-50 rounded border border-gray-200">
                  <h4 className="font-medium mb-2">Lyrics</h4>
                  <p className="whitespace-pre-line text-gray-700">{audio.lyrics}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AudioPlayer;