import React, { useRef, useEffect, useState } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2 } from 'lucide-react';
import useMediaStore from '../../store/mediaStore';

const MiniPlayer: React.FC = () => {
  const { currentMedia, isPlaying, togglePlayback } = useMediaStore();
  const audioRef = useRef<HTMLAudioElement>(null);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(0.7);
  const [audioError, setAudioError] = useState(false);

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying && !audioError) {
        audioRef.current.play().catch(err => {
          console.error('Playback error:', err);
          setAudioError(true);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, currentMedia, audioError]);

  useEffect(() => {
    // Reset error state when media changes
    setAudioError(false);
    setProgress(0);
    setCurrentTime(0);
    setDuration(0);
  }, [currentMedia]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      const current = audioRef.current.currentTime;
      const duration = audioRef.current.duration || 0;
      setCurrentTime(current);
      setProgress((current / (duration || 1)) * 100);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newProgress = parseFloat(e.target.value);
    setProgress(newProgress);
    if (audioRef.current && !isNaN(audioRef.current.duration)) {
      audioRef.current.currentTime = (newProgress / 100) * audioRef.current.duration;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value) / 100;
    setVolume(newVolume);
  };

  const formatTime = (time: number) => {
    if (isNaN(time)) return "0:00";
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  if (!currentMedia || currentMedia.type !== 'audio') return null;

  return (
    <div className="bg-white p-4 shadow-md">
      <audio 
        ref={audioRef}
        src={currentMedia.path}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={() => togglePlayback()}
        onError={() => setAudioError(true)}
      />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center w-1/4">
          <div className="mr-4">
            <button className="p-2 rounded-full hover:bg-gray-200">
              <SkipBack size={20} />
            </button>
            <button 
              className="p-2 rounded-full hover:bg-gray-200 mx-2"
              onClick={togglePlayback}
              disabled={audioError}
            >
              {isPlaying ? <Pause size={20} /> : <Play size={20} />}
            </button>
            <button className="p-2 rounded-full hover:bg-gray-200">
              <SkipForward size={20} />
            </button>
          </div>
        </div>
        
        <div className="flex-1 mx-4">
          <div className="flex justify-between text-xs text-gray-500 mb-1">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={isNaN(progress) ? 0 : progress}
            onChange={handleProgressChange}
            className="w-full h-1 bg-gray-300 rounded-lg appearance-none cursor-pointer"
          />
        </div>
        
        <div className="flex items-center w-1/4 justify-end">
          <Volume2 size={18} className="text-gray-600 mr-2" />
          <input
            type="range"
            min="0"
            max="100"
            value={volume * 100}
            onChange={handleVolumeChange}
            className="w-24 h-1 bg-gray-300 rounded-lg appearance-none cursor-pointer"
          />
        </div>
      </div>
      
      <div className="mt-2 text-center">
        <p className="font-medium">{currentMedia.name}</p>
        {audioError && (
          <p className="text-red-500 text-sm mt-1">
            Unable to play this audio file. The file may be missing or in an unsupported format.
          </p>
        )}
      </div>
    </div>
  );
};

export default MiniPlayer;