import React, { useState } from 'react';
import useMediaStore from '../../store/mediaStore';
import { Image, X } from 'lucide-react';

const ImageGallery: React.FC = () => {
  const { imageFiles, setCurrentMedia } = useMediaStore();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const handleImageClick = (image: any) => {
    setSelectedImage(image.path);
    setCurrentMedia(image);
  };

  const closeModal = () => {
    setSelectedImage(null);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6 flex items-center">
        <Image className="mr-2" />
        Image Gallery
      </h2>
      
      {imageFiles.length === 0 ? (
        <div className="text-center py-10 text-gray-500">
          <p>No images available</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {imageFiles.map((image) => (
            <div 
              key={image.id}
              className="group relative cursor-pointer overflow-hidden rounded-lg shadow-md hover:shadow-lg transition-shadow"
              onClick={() => handleImageClick(image)}
            >
              <img 
                src={image.path} 
                alt={image.name} 
                className="w-full h-48 object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-opacity flex items-end">
                <div className="p-3 w-full bg-gradient-to-t from-black to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                  <h3 className="text-white font-medium truncate">{image.name}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {selectedImage && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
          <div className="relative max-w-4xl max-h-full">
            <button 
              onClick={closeModal}
              className="absolute -top-10 right-0 text-white hover:text-gray-300"
            >
              <X size={24} />
            </button>
            <img 
              src={selectedImage} 
              alt="Enlarged view" 
              className="max-w-full max-h-[80vh] object-contain"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageGallery;