import React, { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import MiniPlayer from '../Media/MiniPlayer';
import useMediaStore from '../../store/mediaStore';

const MainLayout: React.FC = () => {
  const { currentMedia, isPlaying } = useMediaStore();
  const [isMobile, setIsMobile] = useState(false);
  
  // Check if the screen is mobile size
  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkScreenSize();
    window.addEventListener('resize', checkScreenSize);
    
    return () => {
      window.removeEventListener('resize', checkScreenSize);
    };
  }, []);
  
  return (
    <div className="flex h-screen bg-gray-100">
      {!isMobile && <Sidebar />}
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
        
        {currentMedia && currentMedia.type === 'audio' && (
          <div className="border-t border-gray-200">
            <MiniPlayer />
          </div>
        )}
      </div>
    </div>
  );
};

export default MainLayout;