import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Music, Image, Settings, Home, LogOut, User, ChevronRight, ChevronLeft } from 'lucide-react';
import useAuthStore from '../../store/authStore';
import AdminSidebar from '../Admin/AdminSidebar';

const Sidebar: React.FC = () => {
  const { logout, isAuthenticated } = useAuthStore();
  const [showAdminPanel, setShowAdminPanel] = useState(false);

  const toggleAdminPanel = () => {
    setShowAdminPanel(!showAdminPanel);
  };

  return (
    <>
      <div className="bg-gray-900 text-white w-64 min-h-screen p-4 flex flex-col">
        <div className="mb-8">
          <h1 className="text-2xl font-bold flex items-center">
            <Music className="mr-2" size={24} />
            Media Player
          </h1>
        </div>
        
        <nav className="flex-1">
          <ul className="space-y-2">
            <li>
              <NavLink 
                to="/" 
                className={({ isActive }) => 
                  `flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors ${isActive ? 'bg-gray-800' : ''}`
                }
              >
                <Home className="mr-3" size={20} />
                Home
              </NavLink>
            </li>
            <li>
              <NavLink 
                to="/music" 
                className={({ isActive }) => 
                  `flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors ${isActive ? 'bg-gray-800' : ''}`
                }
              >
                <Music className="mr-3" size={20} />
                Music
              </NavLink>
            </li>
            <li>
              <NavLink 
                to="/gallery" 
                className={({ isActive }) => 
                  `flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors ${isActive ? 'bg-gray-800' : ''}`
                }
              >
                <Image className="mr-3" size={20} />
                Gallery
              </NavLink>
            </li>
            {isAuthenticated ? (
              <li>
                <NavLink 
                  to="/admin" 
                  className={({ isActive }) => 
                    `flex items-center p-2 rounded-lg hover:bg-gray-800 transition-colors ${isActive ? 'bg-gray-800' : ''}`
                  }
                >
                  <Settings className="mr-3" size={20} />
                  Admin Panel
                </NavLink>
              </li>
            ) : (
              <li>
                <button
                  onClick={toggleAdminPanel}
                  className="flex items-center justify-between w-full p-2 rounded-lg hover:bg-gray-800 transition-colors"
                >
                  <div className="flex items-center">
                    <User className="mr-3" size={20} />
                    Admin Login
                  </div>
                  {showAdminPanel ? (
                    <ChevronLeft size={16} />
                  ) : (
                    <ChevronRight size={16} />
                  )}
                </button>
              </li>
            )}
          </ul>
        </nav>
        
        {isAuthenticated && (
          <div className="mt-auto pt-4 border-t border-gray-700">
            <button 
              onClick={logout}
              className="flex items-center p-2 w-full text-left rounded-lg hover:bg-gray-800 transition-colors"
            >
              <LogOut className="mr-3" size={20} />
              Logout
            </button>
          </div>
        )}
      </div>

      {/* Admin Sidebar Panel */}
      <AdminSidebar isOpen={showAdminPanel} onClose={toggleAdminPanel} />
    </>
  );
};

export default Sidebar;