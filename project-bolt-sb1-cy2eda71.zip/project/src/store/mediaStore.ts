import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { MediaState, MediaFile } from '../types';

// Mock data - replace with actual API calls in production
const mockAudioFiles: MediaFile[] = [
  {
    id: '1',
    name: 'Sample Song 1',
    path: 'https://assets.codepen.io/4358584/Anitek_-_Komorebi.mp3',
    type: 'audio',
    folderId: 'sample1',
    lyrics: 'Sample lyrics for song 1...',
    cashAppHandle: '$YourCashAppHandle',
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: '2',
    name: 'Sample Song 2',
    path: 'https://assets.codepen.io/4358584/Anitek_-_Tidepool.mp3',
    type: 'audio',
    folderId: 'sample2',
    lyrics: 'Sample lyrics for song 2...',
    cashAppHandle: '$YourCashAppHandle',
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

const mockImageFiles: MediaFile[] = [
  {
    id: '1',
    name: 'Sample Image 1',
    path: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05',
    type: 'image',
    description: 'Beautiful landscape photo',
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: '2',
    name: 'Sample Image 2',
    path: 'https://images.unsplash.com/photo-1501854140801-50d01698950b',
    type: 'image',
    description: 'Mountain scenery',
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

// Sample audio URLs for demo purposes
const sampleAudioUrls = [
  'https://assets.codepen.io/4358584/Anitek_-_Komorebi.mp3',
  'https://assets.codepen.io/4358584/Anitek_-_Tidepool.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'
];

// Sample image URLs for demo purposes
const sampleImageUrls = [
  'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05',
  'https://images.unsplash.com/photo-1501854140801-50d01698950b',
  'https://images.unsplash.com/photo-1441974231531-c6227db76b6e',
  'https://images.unsplash.com/photo-1518791841217-8f162f1e1131',
  'https://images.unsplash.com/photo-1523712999610-f77fbcfc3843'
];

const useMediaStore = create<MediaState & {
  fetchMedia: () => Promise<void>;
  setCurrentMedia: (media: MediaFile | null) => void;
  togglePlayback: () => void;
  uploadMedia: (file: File, type: 'audio' | 'image', metadata?: { description?: string, lyrics?: string, folderName?: string, cashAppHandle?: string }) => Promise<void>;
  deleteMedia: (id: string, type: 'audio' | 'image') => Promise<void>;
  updateMediaMetadata: (id: string, type: 'audio' | 'image', metadata: { name?: string, description?: string, lyrics?: string, cashAppHandle?: string }) => Promise<void>;
  updateCashAppSettings: (cashAppHandle: string) => Promise<void>;
}>(persist(
  (set, get) => ({
    audioFiles: [],
    imageFiles: [],
    currentMedia: null,
    isPlaying: false,
    isLoading: false,
    error: null,
    cashAppHandle: '$YourCashAppHandle',

    fetchMedia: async () => {
      set({ isLoading: true, error: null });
      try {
        // Check if we already have files in the store
        const { audioFiles, imageFiles } = get();
        
        if (audioFiles.length === 0 && imageFiles.length === 0) {
          // Only load mock data if we don't have any files yet
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set({
            audioFiles: mockAudioFiles,
            imageFiles: mockImageFiles,
            isLoading: false
          });
        } else {
          set({ isLoading: false });
        }
      } catch (error) {
        set({
          isLoading: false,
          error: error instanceof Error ? error.message : 'Failed to fetch media files'
        });
      }
    },

    setCurrentMedia: (media) => {
      set({ currentMedia: media, isPlaying: media !== null });
    },

    togglePlayback: () => {
      set(state => ({ isPlaying: !state.isPlaying }));
    },

    uploadMedia: async (file, type, metadata) => {
      set({ isLoading: true, error: null });
      try {
        // Mock upload - replace with actual API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        let folderId = '';
        let path = '';
        
        if (type === 'audio') {
          // Create a folder ID based on the provided folder name or the file name
          folderId = metadata?.folderName || file.name.replace(/\.[^/.]+$/, "");
          
          // In a real app, we would upload to a server
          // For demo, we'll use sample audio URLs
          path = sampleAudioUrls[Math.floor(Math.random() * sampleAudioUrls.length)];
        } else {
          // For images, use a sample image URL instead of object URL for persistence
          path = sampleImageUrls[Math.floor(Math.random() * sampleImageUrls.length)];
        }
        
        const newMedia: MediaFile = {
          id: Math.random().toString(36).substring(2, 9),
          name: file.name,
          path,
          type,
          ...(type === 'audio' ? { 
            lyrics: metadata?.lyrics,
            folderId,
            cashAppHandle: metadata?.cashAppHandle || get().cashAppHandle
          } : { 
            description: metadata?.description 
          }),
          createdAt: new Date(),
          updatedAt: new Date()
        };

        if (type === 'audio') {
          set(state => ({
            audioFiles: [...state.audioFiles, newMedia],
            isLoading: false
          }));
        } else {
          set(state => ({
            imageFiles: [...state.imageFiles, newMedia],
            isLoading: false
          }));
        }
      } catch (error) {
        set({
          isLoading: false,
          error: error instanceof Error ? error.message : 'Failed to upload file'
        });
      }
    },

    deleteMedia: async (id, type) => {
      set({ isLoading: true, error: null });
      try {
        // Mock delete - replace with actual API call
        await new Promise(resolve => setTimeout(resolve, 500));
        
        if (type === 'audio') {
          set(state => ({
            audioFiles: state.audioFiles.filter(file => file.id !== id),
            currentMedia: state.currentMedia?.id === id ? null : state.currentMedia,
            isPlaying: state.currentMedia?.id === id ? false : state.isPlaying,
            isLoading: false
          }));
        } else {
          set(state => ({
            imageFiles: state.imageFiles.filter(file => file.id !== id),
            currentMedia: state.currentMedia?.id === id ? null : state.currentMedia,
            isLoading: false
          }));
        }
      } catch (error) {
        set({
          isLoading: false,
          error: error instanceof Error ? error.message : 'Failed to delete file'
        });
      }
    },

    updateMediaMetadata: async (id, type, metadata) => {
      set({ isLoading: true, error: null });
      try {
        // Mock update - replace with actual API call
        await new Promise(resolve => setTimeout(resolve, 500));
        
        if (type === 'audio') {
          set(state => ({
            audioFiles: state.audioFiles.map(file => 
              file.id === id 
                ? { 
                    ...file, 
                    name: metadata.name || file.name,
                    lyrics: metadata.lyrics !== undefined ? metadata.lyrics : file.lyrics,
                    cashAppHandle: metadata.cashAppHandle || file.cashAppHandle,
                    updatedAt: new Date()
                  }
                : file
            ),
            currentMedia: state.currentMedia?.id === id 
              ? { 
                  ...state.currentMedia, 
                  name: metadata.name || state.currentMedia.name,
                  lyrics: metadata.lyrics !== undefined ? metadata.lyrics : state.currentMedia.lyrics,
                  cashAppHandle: metadata.cashAppHandle || (state.currentMedia as any).cashAppHandle,
                  updatedAt: new Date()
                }
              : state.currentMedia,
            isLoading: false
          }));
        } else {
          set(state => ({
            imageFiles: state.imageFiles.map(file => 
              file.id === id 
                ? { 
                    ...file, 
                    name: metadata.name || file.name,
                    description: metadata.description !== undefined ? metadata.description : file.description,
                    updatedAt: new Date()
                  }
                : file
            ),
            currentMedia: state.currentMedia?.id === id 
              ? { 
                  ...state.currentMedia, 
                  name: metadata.name || state.currentMedia.name,
                  description: metadata.description !== undefined ? metadata.description : state.currentMedia.description,
                  updatedAt: new Date()
                }
              : state.currentMedia,
            isLoading: false
          }));
        }
      } catch (error) {
        set({
          isLoading: false,
          error: error instanceof Error ? error.message : 'Failed to update metadata'
        });
      }
    },

    updateCashAppSettings: async (cashAppHandle) => {
      set({ isLoading: true, error: null });
      try {
        // Mock API call - replace with actual API in production
        await new Promise(resolve => setTimeout(resolve, 300));
        
        set({
          cashAppHandle,
          isLoading: false
        });
      } catch (error) {
        set({
          isLoading: false,
          error: error instanceof Error ? error.message : 'Failed to update CashApp settings'
        });
      }
    }
  }),
  {
    name: 'media-storage', // name of the item in localStorage
    partialize: (state) => ({
      audioFiles: state.audioFiles,
      imageFiles: state.imageFiles,
      cashAppHandle: state.cashAppHandle
    }),
  }
));

export default useMediaStore;