import { create } from 'zustand';
import { AuthState } from '../types';

// This is a mock implementation. In a real app, you would connect to a backend
const useAuthStore = create<AuthState & {
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  checkAuth: () => Promise<void>;
}>((set) => ({
  user: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,

  login: async (username: string, password: string) => {
    set({ isLoading: true, error: null });
    try {
      // Mock login - replace with actual API call
      if (username === 'admin' && password === 'password') {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        set({
          user: {
            id: '1',
            username: 'admin',
            isAdmin: true
          },
          isAuthenticated: true,
          isLoading: false
        });
      } else {
        throw new Error('Invalid credentials');
      }
    } catch (error) {
      set({
        isLoading: false,
        error: error instanceof Error ? error.message : 'An unknown error occurred'
      });
    }
  },

  logout: () => {
    set({
      user: null,
      isAuthenticated: false,
      error: null
    });
  },

  checkAuth: async () => {
    set({ isLoading: true });
    try {
      // Mock auth check - replace with actual API call
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // For demo purposes, we'll assume no stored session
      set({
        user: null,
        isAuthenticated: false,
        isLoading: false
      });
    } catch (error) {
      set({
        isLoading: false,
        error: error instanceof Error ? error.message : 'An unknown error occurred'
      });
    }
  }
}));

export default useAuthStore;